"""
Generates a synthetic but realistic student performance dataset.
Run once: python generate_data.py
Produces: student_performance.csv (used by the app)
Seeded for reproducibility -- same file every time it's run.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 400
cities = ["Karachi", "Lahore", "Islamabad", "Multan", "Peshawar"]

study_hours = np.round(np.random.normal(4, 1.8, N).clip(0, 10), 1)
attendance = np.round(np.random.normal(78, 12, N).clip(30, 100), 1)
previous_score = np.round(np.random.normal(65, 15, N).clip(20, 100), 1)
sleep_hours = np.round(np.random.normal(6.5, 1.3, N).clip(3, 10), 1)
extra_classes = np.random.choice([0, 1], size=N, p=[0.6, 0.4])
city = np.random.choice(cities, size=N)

# Underlying "true" score signal (a formula) + noise -- this is what the
# ML models will try to learn from the visible features alone.
signal = (
    study_hours * 6.5
    + attendance * 0.35
    + previous_score * 0.25
    + sleep_hours * 1.5
    + extra_classes * 4
    + np.random.normal(0, 8, N)
)

final_score = np.round(np.clip(signal / 1.4, 0, 100), 1)
passed = (final_score >= 50).astype(int)

df = pd.DataFrame({
    "study_hours_daily": study_hours,
    "attendance_percent": attendance,
    "previous_score": previous_score,
    "sleep_hours": sleep_hours,
    "extra_classes": extra_classes,
    "city": city,
    "final_score": final_score,
    "passed": passed
})

df.to_csv("student_performance.csv", index=False)
print(f"Saved student_performance.csv with {len(df)} rows")
print(f"Pass rate: {df['passed'].mean()*100:.1f}%")
